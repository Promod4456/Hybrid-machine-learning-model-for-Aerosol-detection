﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlServerCe;
using System.IO;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Drawing.Imaging;
using System.Data.OleDb;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        
        public static string GetConnectionString()
        {
            string ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" +
            "Data Source=" + Application.StartupPath + "\\Book.accdb;";
            return ConnectionString;
        }
        string name;
        
        public Form1()
        {
            InitializeComponent();
           
            hidemenu();
            
        }
        OleDbConnection con;
        OleDbCommand cmd;
        MemoryStream ms;
        string cs = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Store_PICS.accdb;Persist Security Info=False;";
        private void hidemenu()
        {
            panel4.Visible = false;
                    }
        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hidemenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            var myForm2 = new Form2();
            myForm2.Show();
        } 

        private void button1_Click(object sender, EventArgs e)
        {
            showSubMenu(panel4);
         
           
        }
       
        private void button2_Click(object sender, EventArgs e)
        {


        }
        
        private void button7_Click(object sender, EventArgs e)
        {
            {
                con = new OleDbConnection(cs);
                con.Open();
                string cb = "insert into Book(Img_ID,Pics) VALUES('" + MyNumber + "',@image)";
                cmd = new OleDbCommand(cb);
                cmd.Connection = con;
                var ms = new MemoryStream();
                var bmpImage = new Bitmap(pictureBox2.Image);
                bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                var data = ms.GetBuffer();
                var p = new OleDbParameter("@image", OleDbType.VarBinary);
                p.Value = data;
                cmd.Parameters.Add(p);
                cmd.ExecuteNonQuery();
                con.Close();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        

       

       
        private void button8_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
             
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Menu", button1);

        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Search", button2);

        }
        private void button3_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Library", button3);

        }
        private void button7_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Save", button7);

        }
        private void button4_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Reports", button4);

        }
        private void button10_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Help", button10);

        }
        private void button11_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("About", button11);

        }
        private void button12_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Scope Analyze", button12);

        }
        private void button13_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Import Analyze", button13);

        }

        private void button14_MouseHover(object sender, EventArgs e)
        {
            toolTip1.Show("Save Image", button14);

        }
       

        private bool mouseDown;
        private Point lastLocation;

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }
        
        private void button6_Click(object sender, EventArgs e)
        {
            NewNumber();
            // open file dialog   
            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {

                // image file path  
                textBox1.Text = open.FileName;
                pictureBox2.ImageLocation = open.FileName ;
            }  
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
            
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x20000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle |= CS_DROPSHADOW;
                return cp;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            {
    con = new OleDbConnection(cs);
    con.Open();
    string cb = "insert into Book(Img_ID,Pics) VALUES('" + MyNumber + "',@image)";
    cmd = new OleDbCommand(cb);
    cmd.Connection = con;
    var ms = new MemoryStream();
    var bmpImage = new Bitmap(pictureBox2.Image);
    bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
    var data = ms.GetBuffer();
    var p = new OleDbParameter("@image", OleDbType.VarBinary);
    p.Value = data;
    cmd.Parameters.Add(p);
    cmd.ExecuteNonQuery();
    con.Close();
}


        }

        private void button15_Click(object sender, EventArgs e)
        {
          
        }
        void conv_photo()
        {
            //converting photo to binary data
            if (pictureBox2.Image != null)
            {
                //using FileStream:(will not work while updating, if image is not changed)
                //FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                //byte[] photo_aray = new byte[fs.Length];
                //fs.Read(photo_aray, 0, photo_aray.Length);  

                //using MemoryStream:
                ms = new MemoryStream();
                pictureBox2.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_aray = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_aray, 0, photo_aray.Length);
                cmd.Parameters.AddWithValue("@photo", photo_aray);
            }
        }
        private void button15_Click_1(object sender, EventArgs e)
        {

        }
        public Random a = new Random(); // replace from new Random(DateTime.Now.Ticks.GetHashCode());
        // Since similar code is done in default constructor internally
        public List<int> randomList = new List<int>();
        int MyNumber = 0;
        private void NewNumber()
        {
            MyNumber = a.Next(0, 1000);
            if (!randomList.Contains(MyNumber))
                randomList.Add(MyNumber);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            NewNumber();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {
            var myForm2 = new Form2();
            myForm2.Show();
        }

        private void button17_Click(object sender, EventArgs e)
        {
                              
        }

        private void button18_Click(object sender, EventArgs e)
        {
            var myForm1 = new Form3();
            myForm1.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var myForm1 = new Form3();
            myForm1.Show();
        }

    }
}

