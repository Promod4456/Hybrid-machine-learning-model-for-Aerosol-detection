﻿CREATE TABLE [dbo].[Table]
(
	[Image ID] INT NOT NULL PRIMARY KEY, 
    [Pics] IMAGE NULL
)
